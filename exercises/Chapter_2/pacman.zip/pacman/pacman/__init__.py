__all__ = ['level', 'character', 'pacman', 'ghost', 'blinky', 'pinky', 'inky', 'clyde']
